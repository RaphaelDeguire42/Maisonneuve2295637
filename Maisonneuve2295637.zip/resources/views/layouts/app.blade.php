<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.0/mdb.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{asset("css/main.css")}}">

</head>
<body>
    <nav class="navbar navbar-expand-lg lightText">
    <div class="container-fluid">
         @php $lang =  session('locale') @endphp
        <a class="navbar-brand lightText" href="#">@lang('lang.text_hello') {{ Auth::user()->name ?? trans('lang.text_guest')  }}</a>
        <span class="spacer"></span>

        <div class="navbar-nav">
                @guest
                <a class="nav-link " href="{{route('login')}}">@lang('lang.text_login')</a>
                @else
                <a class="nav-link " href="{{route('etudiant.index')}}">@lang('lang.text_studentList')</a>
                <a class="nav-link " href="{{route('forum.index')}}">Forum</a>
                <a class="nav-link " href="{{route('logout')}}">@lang('lang.text_logout')</a>
                @endguest
                <span class="nav-link">-</span>
                @if ($lang == 'fr')
                <a class="nav-link @if($lang=='en') text-primary @endif"" href="{{route('lang', 'en')}}">@lang('lang.text_english') <i class="flag flag-united-states"></i></a>
                @else
                <a class="nav-link  @if($lang=='fr') text-primary @endif" href="{{route('lang', 'fr')}}">@lang('lang.text_french') <i class="flag flag-france"></i></a>
                @endif
        </div>
       
    </div>
    </nav>
    @yield('content')
</body>
</html>