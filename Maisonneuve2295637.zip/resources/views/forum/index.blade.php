@extends('layouts.app')
@section('title', 'Forum')
@section('content')
    @if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
    @endif
    <div class="forum">
    <h1>@lang('lang.text_forumTitle')</h1>
    @forelse ($posts as $post)
        <div class="post">
            <div class="post__header">
                <div class="post__topHeader">
                    <p>{{$post->title}}</p>
                    <span>{{$post->created_at}}</span>
                </div>
                <div class="post__bottomHeader">
                    <p>Par : {{$post->postHasAuthor->name}}</p>
                </div>
            </div>
            <div class="post__content">
                <p>{{$post->content}}</p>
            </div>
            <div class="post__footer action">
                @if (session('user_id') == $post->postHasAuthor->id)
                    <a href="" class="button">@lang('lang.text_edit')</a>
                    <form action="{{ route('forum.destroy', $post->id) }}" method="POST"> @csrf @method('DELETE')
                        <button class="button button--delete" type="submit">@lang('lang.text_delete')</button>
                    </form>
                @endif
            </div>
        </div>
    @empty
        <p>@lang('lang.text_noStudent')</p>
    @endforelse
    </div>
@endsection