
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-5 justify-content-center">
        <div class="col-lg-6">
            <?php if(!$errors->isEmpty()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="card">
                <form action="<?php echo e(route('authentication')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-header text-center">
                        <h1 class="display-6"><?php echo app('translator')->get('lang.text_login'); ?></h1>
                    </div>
                    <div class="card-body">
                        <div class="form-group mb-3">
                            <label for="email"><?php echo app('translator')->get('lang.text_email'); ?></label>
                            <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email')); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label for="password"><?php echo app('translator')->get('lang.text_password'); ?></label>
                            <input type="password" name="password" id="password" class="form-control">
                        </div>
                    </div>
                    <div class="card-footer text-center">
                            <input type="submit" value="Login" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rapha\OneDrive\Desktop\Ecole\Session 4\cadriciel\Maisonneuve2295637\resources\views/user/login.blade.php ENDPATH**/ ?>