
<?php $__env->startSection('title', 'Liste des étudiants'); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper table">
    <h1 class="table__title">Liste des étudiants</h1>
    <div class="action">
        <a href="<?php echo e(route('etudiant.welcome')); ?>" type="button" class="button button--neutral">Retour</a>
        <a href="<?php echo e(route('etudiant.create')); ?>" class="button button--neutral">Ajouter un étudiant</a>
    </div>

    <!-- Retour de succes si l'étudiant est bien supprimé -->
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <ul class="table__content">
        <?php $__empty_1 = true; $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li class="table__row">
            <a href="<?php echo e(route('etudiant.show', $etudiant->id )); ?>"><?php echo e($etudiant->name); ?></a>
            <div class="action">
                <a href="<?php echo e(route('etudiant.edit', $etudiant->id )); ?>" class="button">Modifier</a>
                <form action="<?php echo e(route('etudiant.destroy', $etudiant->id)); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="button button--delete" type="submit">Supprimer</button>
                </form>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <li class="table__row">
            <p>Aucun étudiant pour le moment...</p>
        </li>
        <?php endif; ?>
    </ul>
<?php echo e($etudiants); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rapha\OneDrive\Desktop\Ecole\Session 4\cadriciel\Maisonneuve2295637\resources\views\etudiant\index.blade.php ENDPATH**/ ?>