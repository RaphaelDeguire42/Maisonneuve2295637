<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.0/mdb.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset("css/main.css")); ?>">

</head>
<body>
    <nav class="navbar navbar-expand-lg lightText">
    <div class="container-fluid">
         <?php $lang =  session('locale') ?>
        <a class="navbar-brand lightText" href="#"><?php echo app('translator')->get('lang.text_hello'); ?> <?php echo e(Auth::user()->name ?? trans('lang.text_guest')); ?></a>
        <span class="spacer"></span>

        <div class="navbar-nav">
                <?php if(auth()->guard()->guest()): ?>
                <a class="nav-link " href="<?php echo e(route('login')); ?>"><?php echo app('translator')->get('lang.text_login'); ?></a>
                <?php else: ?>
                <a class="nav-link " href="<?php echo e(route('etudiant.index')); ?>"><?php echo app('translator')->get('lang.text_studentList'); ?></a>
                <a class="nav-link " href="<?php echo e(route('forum.index')); ?>">Forum</a>
                <a class="nav-link " href="<?php echo e(route('logout')); ?>"><?php echo app('translator')->get('lang.text_logout'); ?></a>
                <?php endif; ?>
                <span class="nav-link">-</span>
                <?php if($lang == 'fr'): ?>
                <a class="nav-link <?php if($lang=='en'): ?> text-primary <?php endif; ?>"" href="<?php echo e(route('lang', 'en')); ?>"><?php echo app('translator')->get('lang.text_english'); ?> <i class="flag flag-united-states"></i></a>
                <?php else: ?>
                <a class="nav-link  <?php if($lang=='fr'): ?> text-primary <?php endif; ?>" href="<?php echo e(route('lang', 'fr')); ?>"><?php echo app('translator')->get('lang.text_french'); ?> <i class="flag flag-france"></i></a>
                <?php endif; ?>
        </div>
       
    </div>
    </nav>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\Users\rapha\OneDrive\Desktop\Ecole\Session 4\cadriciel\Maisonneuve2295637\resources\views/layouts/app.blade.php ENDPATH**/ ?>