
<?php $name = $etudiant->name; ?>
<?php $__env->startSection('title', $name); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper table">
    <h2><?php echo e($etudiant->name); ?></h2>
    <div class="table__content info">
        <p class="table__row">Date de naissance: <span class="info__data"><?php echo e($etudiant->date_of_birth); ?></span></p>
        <p class="table__row">Téléphone: <span class="info__data"><?php echo e($etudiant->phone); ?></span></p>
        <p class="table__row">Courriel: <span class="info__data"><?php echo e($etudiant->email); ?></span></p>
        <p class="table__row">Adresse: <span class="info__data adress"><?php echo e($etudiant->adress); ?></span></p>
        <p class="table__row">Ville: <span class="info__data"><?php echo e($etudiant->etudiantHasVille->name); ?></span></p>
    </div>
    <div class="action">
        <a href="<?php echo e(route('etudiant.index')); ?>" type="button" class="button button--neutral">Retour</a>
        <a href="<?php echo e(route('etudiant.edit', $etudiant->id )); ?>" class="button">Modifier</a>
        <form action="<?php echo e(route('etudiant.destroy', $etudiant->id)); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="button button--delete" type="submit">Supprimer</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rapha\OneDrive\Desktop\Ecole\Session 4\cadriciel\Maisonneuve2295637\resources\views\etudiant\show.blade.php ENDPATH**/ ?>