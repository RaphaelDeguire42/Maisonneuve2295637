
<?php $__env->startSection('title', 'Forum'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <div class="forum">
    <h1><?php echo app('translator')->get('lang.text_forumTitle'); ?></h1>
    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="post">
            <div class="post__header">
                <div class="post__topHeader">
                    <p><?php echo e($post->title); ?></p>
                    <span><?php echo e($post->created_at); ?></span>
                </div>
                <div class="post__bottomHeader">
                    <p>Par : <?php echo e($post->postHasAuthor->name); ?></p>
                </div>
            </div>
            <div class="post__content">
                <p><?php echo e($post->content); ?></p>
            </div>
            <div class="post__footer action">
                <?php if(session('user_id') == $post->postHasAuthor->id): ?>
                    <a href="" class="button"><?php echo app('translator')->get('lang.text_edit'); ?></a>
                    <form action="<?php echo e(route('forum.destroy', $post->id)); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="button button--delete" type="submit"><?php echo app('translator')->get('lang.text_delete'); ?></button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Aucun post pour le moment</p>
    <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rapha\OneDrive\Desktop\Ecole\Session 4\cadriciel\Maisonneuve2295637\resources\views/forum/index.blade.php ENDPATH**/ ?>