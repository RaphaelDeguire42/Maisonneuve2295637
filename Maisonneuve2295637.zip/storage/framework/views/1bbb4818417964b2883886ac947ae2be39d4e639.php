<?php $__env->startSection('title', 'Accueil'); ?>
<?php $__env->startSection('content'); ?>

<header>
    <h1>Administration des étudiants</h1>
    <a class="button glow" href="<?php echo e(route("etudiant.index")); ?> ">Voir la liste des étudiants</a>
</header>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rapha\OneDrive\Desktop\Ecole\Session 4\cadriciel\Maisonneuve2295637\resources\views\welcome.blade.php ENDPATH**/ ?>