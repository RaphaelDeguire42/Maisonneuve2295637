
<?php $__env->startSection('title', 'Modifier un étudiant'); ?>
<?php $__env->startSection('content'); ?>
 <form class="form-labels-on-top" method="post" action="#">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="form-title-row">
        <h1>Modifier un étudiant</h1>
    </div>
    <div class="form-row">
        <label for="name">
            <span>Nom</span>
            <input type="text" id="name" name="name" value="<?php echo e($etudiant->name); ?>" required>
        </label>
    </div>
    <div class="form-row">
        <label for="email">
            <span>Courriel</span>
            <input type="email" id="email" name="email" value="<?php echo e($etudiant->email); ?>" required>
        </label>
    </div>
    <div class="form-row">
        <label for="phone">
            <span>Téléphone (XXX-XXX-XXXX)</span>
            <input type="tel" id="phone" name="phone" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" value="<?php echo e($etudiant->phone); ?>" required>
        </label>
    </div>
    <div class="form-row">
        <label for="adress">
            <span>Adresse</span>
            <textarea type="text" id="adress" name="adress" required><?php echo e($etudiant->adress); ?></textarea>
        </label>
    </div>
    <div class="form-row">
        <label for="date_of_birth">
            <span>Date de naissance</span>
            <input type="date" id="date_of_birth" name="date_of_birth" value="<?php echo e($etudiant->date_of_birth); ?>" required>
        </label>
    </div>
    <div class="form-row">
        <label for="ville">
            <span>Ville</span>
            <select name="ville" id="ville" required>
                <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($etudiant->ville_id == $ville->id): ?>
                    <option value="<?php echo e($ville->id); ?>" selected><?php echo e($ville->name); ?></option>
                    <?php else: ?>
                    <option value="<?php echo e($ville->id); ?>"><?php echo e($ville->name); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
    </div>
    <div class="action">
        <a href="<?php echo e(route('etudiant.index')); ?>" type="button" class="button button--neutral">Retour</a>
        <button type="submit" class="button">Enregistrer</button>
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rapha\OneDrive\Desktop\Ecole\Session 4\cadriciel\Maisonneuve2295637\resources\views/etudiant/edit.blade.php ENDPATH**/ ?>