#Steps to make users from students:

- add foreing key that references the id of Etudiant
- add this code to the migration of user
```
$students = Etudiant::all();
foreach ($students as $student) {
    $user = new User();
    $user->id = $student->id; //
    $user->name = $student->name; //
    $user->email = $student->email; //
    $user->password = Hash::make('password');
    $user->etudiant_id = $student->id; //
    $user->save();
}
```
- migrate the table villes and populate with the factory
- migrate the table etudiants and populate with the factory
- migrate the table users

Now every etudiants has a corresponding user with the same id, name, and email with a generated password


Login :
palma19@example.org
E2295637@Maisonneuve